# Running the program shows that we executed about
# 40,000 operations.
$ go run atomic-counters.go
ops: 41419

# Next we'll look at mutexes, another tool for managing
# state.
