$ go run non-blocking-channel-operations.go 
no message received
no message sent
no activity
