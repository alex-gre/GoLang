$ go run range-over-channels.go
one
two

# This example also showed that it's possible to close
# a non-empty channel but still have the remaining
# values be received.
