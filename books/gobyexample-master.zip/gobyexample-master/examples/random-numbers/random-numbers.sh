$ go run random-numbers.go
81,87
0.6645600532184904
7.123187485356329,8.434115364335547
0,28
5,87
5,87


# See the [`math/rand`](http://golang.org/pkg/math/rand/)
# package docs for references on other random quantities
# that Go can provide.
